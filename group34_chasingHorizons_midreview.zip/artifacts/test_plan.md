# 🧾 Sign-Up Form Validation – Test Report

### ✅ **Overview**

All validation constraints for the **Sign-Up Form** have been implemented and tested successfully.  
The form now correctly validates user input for **Name, Email, Mobile, Password** fields according to defined business rules.

---

## 🧍‍♂️ Name Field

| **Test Scenario**                                 | **Expected Behavior**                                               | **Actual Result**              |
| ------------------------------------------------- | ------------------------------------------------------------------- | ------------------------------ |
| Name is empty                                     | Show “Name cannot be empty”                                         | ✅ Message displayed correctly |
| Single character input                            | Reject (must be ≥ 2 characters)                                     | ✅ Rejected correctly          |
| More than 60 characters                           | Reject (must be ≤ 60 characters)                                    | ✅ Rejected correctly          |
| Name starts with number                           | Reject with message “Name should not start with a number”           | ✅ Rejected correctly          |
| Name contains numbers (e.g., John123)             | Reject with message “Name should contain only alphabets and spaces” | ✅ Rejected correctly          |
| Name contains special characters (e.g., John@Doe) | Reject with message “Name should contain only alphabets and spaces” | ✅ Rejected correctly          |
| Valid name (e.g., John Doe)                       | Accepted                                                            | ✅ Accepted correctly          |

---

## 📧 Email Field

| **Test Scenario**                        | **Expected Behavior**                      | **Actual Result**                           |
| ---------------------------------------- | ------------------------------------------ | ------------------------------------------- |
| Email empty                              | Show “Email cannot be empty”               | ✅ Message displayed correctly              |
| Missing @ symbol (e.g., userexample.com) | Reject                                     | ✅ Rejected correctly                       |
| Double @@ (e.g., user@@example.com)      | Reject                                     | ✅ Rejected correctly                       |
| Invalid domain (e.g., user@.com)         | Reject                                     | ✅ Rejected correctly                       |
| Valid format (e.g., user@example.com)    | Accepted                                   | ✅ Accepted correctly                       |
| Duplicate email entry                    | Reject and show “Email already registered” | ✅ Detected duplicate (handled via backend) |

---

## 📱 Mobile Number Field

| **Test Scenario**             | **Expected Behavior**        | **Actual Result**              |
| ----------------------------- | ---------------------------- | ------------------------------ |
| Empty phone field             | Show “Phone cannot be empty” | ✅ Message displayed correctly |
| Less than 10 digits           | Reject                       | ✅ Rejected correctly          |
| More than 10 digits           | Reject                       | ✅ Rejected correctly          |
| Contains alphabets or symbols | Reject                       | ✅ Rejected correctly          |
| Valid 10-digit number         | Accepted                     | ✅ Accepted correctly          |

---

## 🔒 Password Field

| **Test Scenario**                  | **Expected Behavior**                                     | **Actual Result**              |
| ---------------------------------- | --------------------------------------------------------- | ------------------------------ |
| Password empty                     | Show “Password cannot be empty”                           | ✅ Message displayed correctly |
| Less than 8 characters             | Reject with “Password must be at least 8 characters long” | ✅ Rejected correctly          |
| Missing uppercase letter           | Reject with “Must contain at least one uppercase letter”  | ✅ Rejected correctly          |
| Missing lowercase letter           | Reject with “Must contain at least one lowercase letter”  | ✅ Rejected correctly          |
| Missing number                     | Reject with “Must contain at least one number”            | ✅ Rejected correctly          |
| Missing special character          | Reject with “Must contain at least one special character” | ✅ Rejected correctly          |
| Valid password (e.g., P@ssword123) | Accepted                                                  | ✅ Accepted correctly          |

---

# 🧾 Package Form Validation (Create / Edit)

| **Test Scenario**                    | **Expected Behavior**                                                                        | **Actual Result**              |
| ------------------------------------ | -------------------------------------------------------------------------------------------- | ------------------------------ |
| Title empty                          | Reject and show "Title cannot be empty"                                                      | ✅ Message displayed correctly |
| Title too short (1-2 chars)          | Reject and show "Title must be at least 3 characters long"                                   | ✅ Message displayed correctly |
| Title too long (>150 chars)          | Reject and show "Title cannot exceed 150 characters"                                         | ✅ Message displayed correctly |
| Rating invalid (<1 or >5)            | Reject and show "Rating must be a number between 1 and 5"                                    | ✅ Message displayed correctly |
| Price amount empty                   | Reject and show "Price amount is required"                                                   | ✅ Message displayed correctly |
| Price amount negative                | Reject and show "Price amount must be a non-negative number"                                 | ✅ Message displayed correctly |
| Price discount invalid (>=1 or <0)   | Reject and show "Price discount must be a number between 0 (inclusive) and 1 (exclusive)"    | ✅ Message displayed correctly |
| Main image invalid URL               | Reject and show "Main image must be a valid URL"                                             | ✅ Message displayed correctly |
| One or more other images invalid URL | Reject and show "All images must be valid URLs"                                              | ✅ Message displayed correctly |
| Destination missing name             | Reject and show "Each destination must have a name"                                          | ✅ Message displayed correctly |
| Destination image invalid URL        | Reject and show "Destination images must be valid URLs"                                      | ✅ Message displayed correctly |
| Itinerary day missing or non-number  | Reject and show "Itinerary day must be a valid number"                                       | ✅ Message displayed correctly |
| Itinerary location missing           | Reject and show "Each itinerary day must have a location"                                    | ✅ Message displayed correctly |
| Booking missing start or end date    | Reject and show "Each booking must have a start date" / "Each booking must have an end date" | ✅ Message displayed correctly |

---
