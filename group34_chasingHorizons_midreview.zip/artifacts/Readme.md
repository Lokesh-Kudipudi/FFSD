# Chasing Horizons 🌍

_Group ID:_ 34  
_Project Title:_ Chasing Horizons

## CORE FFSD Functionalities

### Done

1. Template Rendering Engine using EJS
2. Backend using MongoDB
3. CRUD operations for Tours, Hotels, Users
4. Dashboards for User, Admin and Hotel Manager

### To be Done

1. Review System
2. Payment System
3. Realtime Festival Info

## SPOC

Lokesh Kudipudi  
📧 lokesh.k23@iiits.in  
🎓 Roll No: S20230010135

## 👥 Team Members & RolesI

1. Lokesh Kudipudi - Gemini + Chatbot
2. Meghana Kuruva - Hotel Manager Dashboard
3. Rohin Sai Bhogadi - Admin & User Dashboards
4. Thotham Reddy Palla - Hotels System & Auth Backend
5. Sneha Sri Sai Vadde - Login UI & Contact System

## Installation

1. Clone the repository:

```bash
git clone https://github.com/Lokesh-Kudipudi/FFSD.git
cd FFSD
```

2. Install dependencies:

```bash
npm install
```

3. Create a `.env` file in the root directory with the following environment variables:

```env
MONGODB_URI=your_mongodb_connection_string
JWT_SECRET=your_jwt_secret_key
GOOGLE_API_KEY=your_google_api_key  # Required for Gemini AI integration
```

## Running the Application

1. For development with auto-reload:

```bash
npm run dev
```

2. For production:

```bash
node app.js
```

The application will start running on `http://localhost:3000` (or the port specified in your environment variables).

## Demo Link

Youtube Link :- https://www.youtube.com/watch?v=_JQZrn23eGg

00:00 to 01:00 - Title slide (Group ID, Project Title, Team lead) and your project business case \
01:00 to 01:55 - Form Validation in Sign Up page and Backend Code \
01:55 to 03:00 - Dynamic HTML in Chatbot Interface \
03:00 to 04:33 - Async Demo + Code \
04:33 to 06:00 - Individual Contribution \
06:00 to 06:29 - Artifacts Evidence

## Key Files and Functions (Validation, Dynamic HTML & API)

### Form Validation

- **Client-Side Validation (`/public/js/auth/signUp.js`, `/public/js/auth/signUpHotelManager.js`)**

  - Name validation: Length checks (2-60 chars), alphanumeric restrictions
  - Email validation: Format checking with regex pattern
  - Phone validation: 10-digit number requirement
  - Password validation: Minimum length requirements
  - Real-time feedback using toast notifications

### Dynamic HTML Generation

- **Dashboard System**

  - Dynamic rendering of analytics data for different user roles
  - Real-time booking statistics and visualizations
  - Role-specific content loading (Admin, Hotel Manager, User views)

- **Tour and Hotel Management**
  - Dynamic room type management for hotel managers
  - Tour package creation with dynamic form validation
  - Real-time updates for bookings and availability

### API Routes and Controllers

- **Authentication Routes (`/routes/userRouter.js`)**

  - `/signUp` - New user registration
  - `/signUpHotelManager` - Hotel manager registration
  - `/signIn` - User authentication
  - `/logout` - Session termination

- **Dashboard Routes (`/routes/dashboardRouter.js`)**

  - Analytics endpoints for different user roles
  - Booking management APIs
  - Hotel and tour management endpoints

- **Feature Controllers**
  - `userController.js` - User management and authentication
  - `bookingController.js` - Booking operations
  - `hotelController.js` - Hotel management
  - `tourController.js` - Tour package management
  - `analyticsController.js` - Business analytics
