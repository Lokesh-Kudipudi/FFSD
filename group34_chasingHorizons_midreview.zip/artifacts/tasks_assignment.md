1. Lokesh Kudipudi \
   &nbsp;&nbsp;&nbsp;&nbsp; Tours System + Gemini AI Integration \
   &nbsp;&nbsp;&nbsp;&nbsp; - Implemented complete MVC architecture for tours (`Model/tourModel.js`, `Controller/tourController.js`, `routes/toursRouter.js`) \
   &nbsp;&nbsp;&nbsp;&nbsp; - Created tour views with EJS templating (`views/tours/`) \
   &nbsp;&nbsp;&nbsp;&nbsp; - Developed advanced tour search with filters (duration, location, price range, etc.) \
   &nbsp;&nbsp;&nbsp;&nbsp; - Integrated Google Gemini API for AI-powered tour recommendations (`api/gemini.js`) \
   &nbsp;&nbsp;&nbsp;&nbsp; - Built interactive chatbot interface with real-time responses

2. Meghana Kuruva \
   &nbsp;&nbsp;&nbsp;&nbsp; Hotel Manager Dashboard \
   &nbsp;&nbsp;&nbsp;&nbsp; - Developed hotel management interface (`views/dashboard/hotelManager/`) \
   &nbsp;&nbsp;&nbsp;&nbsp; - Created room management system with CRUD operations \
   &nbsp;&nbsp;&nbsp;&nbsp; - Implemented booking management and room inventory \
   &nbsp;&nbsp;&nbsp;&nbsp; - Built hotel analytics dashboard with metrics visualization

3. Rohin Sai Bhogadi \
   &nbsp;&nbsp;&nbsp;&nbsp; Admin & User Dashboards \
   &nbsp;&nbsp;&nbsp;&nbsp; - Built comprehensive admin control panel (`views/dashboard/admin/`) \
   &nbsp;&nbsp;&nbsp;&nbsp; - Implemented user dashboard with booking management \
   &nbsp;&nbsp;&nbsp;&nbsp; - Created analytics system (`Controller/analyticsController.js`) \
   &nbsp;&nbsp;&nbsp;&nbsp; - Developed package management interface \
   &nbsp;&nbsp;&nbsp;&nbsp; - Added user profile management system

4. Thotam Reddy Palla \
   &nbsp;&nbsp;&nbsp;&nbsp; Hotels System \
   &nbsp;&nbsp;&nbsp;&nbsp; - Developed complete hotel management system (`Model/hotelModel.js`, `Controller/hotelController.js`) \
   &nbsp;&nbsp;&nbsp;&nbsp; - Created hotel search and filtering system \
   &nbsp;&nbsp;&nbsp;&nbsp; - Built hotel detail pages with amenities display \
   &nbsp;&nbsp;&nbsp;&nbsp; - Added hotel booking system \
   &nbsp;&nbsp;&nbsp;&nbsp; - Implemented auto sign-in feature (`Middleware/autoSignIn.js`) \
   &nbsp;&nbsp;&nbsp;&nbsp; - Created role-based authentication middleware (`Middleware/authentication.js`) \
   &nbsp;&nbsp;&nbsp;&nbsp; - Created JWT-based session management

5. Sneha Sri Sai Vadde \
   &nbsp;&nbsp;&nbsp;&nbsp; Login UI & Contact System \
   &nbsp;&nbsp;&nbsp;&nbsp; - Implemented the UI for login system \
   &nbsp;&nbsp;&nbsp;&nbsp; - Implemented Form validation using DOM in frontend \
   &nbsp;&nbsp;&nbsp;&nbsp; - Built contact form with backend integration (`Model/contactModel.js`, `Controller/contactController.js`) \
   &nbsp;&nbsp;&nbsp;&nbsp; - Added query management system for admin
