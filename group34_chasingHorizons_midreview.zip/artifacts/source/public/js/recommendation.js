function handleTourClick(tourId) {
  window.location.href = `${window.location.protocol}//${window.location.host}/tours/tour/${tourId}`;
}
